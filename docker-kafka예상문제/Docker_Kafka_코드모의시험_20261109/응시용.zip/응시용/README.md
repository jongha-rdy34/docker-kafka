# Docker & Kafka 코드 모의시험 시작 안내

2026-11-09 평가 대비 | 12문항 / 100점 / 110분

시간·배점·제출 규칙은 이 모의시험 전용입니다. 실제 평가의 시간·배점·제출 방식은 확인되지 않았습니다. 문제지.md를 읽고 answers와 tasks를 수정하세요. PDF는 전체 패키지의 상위 output/pdf에 있으며, 응시용.zip에서는 이 폴더 안에도 들어 있습니다.

## 환경 가정

Kafka CLI 문제는 공통 docker-compose.yml만 이미 실행된 상태를 가정합니다. 이 파일은 실제 Setup.exe 산출물을 확보한 것이 아니라 강사 치트시트와 공식 문서를 토대로 만든 가상 연습 환경입니다. 단일 브로커 KRaft이며 서비스는 kafka 하나뿐입니다. ZooKeeper나 추가 서버는 없습니다. 제작 과정에서 이 컴퓨터에 설치·기동하지 않았습니다.

필요 환경: Linux 컨테이너를 실행하는 Docker Engine, Docker Compose v2.20 이상(가정), 편집기. 호스트 포트 9092·5080·8088이 비어 있어야 합니다. 이미지: confluentinc/cp-kafka:7.6.1, python:3.10.16-slim, alpine:3.21.3, nginx:1.27.4-alpine. Python 3.10, kafka-python==2.0.4는 실습에 맞추었고 Flask==3.0.3은 연습용 고정 버전입니다. 전이 의존성과 이미지 digest까지 고정하지는 않았습니다. 최초 이미지 다운로드와 컨테이너 내부 패키지 설치에는 인터넷이 필요합니다. 호스트에 Java·Kafka·Python을 따로 설치하지 않습니다.

탐색기에서 압축을 해제하고 편집기로 이 README가 있는 응시용 폴더를 여세요. 해당 폴더에서 터미널을 엽니다. 모든 명령은 한 줄이며 WSL bash 또는 PowerShell 7의 ${PWD} 경로 확장을 가정합니다. 경로 따옴표를 유지하세요. 파일 수정·폴더 열기는 편집기와 탐색기를 사용합니다.

## 준비: 시간 측정 전에 완료

이미 Docker 환경이 있고 실제 실행 연습을 할 때만 직접 수행합니다. 기존 시험 설정 파일을 덮어쓰지 마세요.

~~~text
docker compose config --quiet
docker compose up -d --wait --wait-timeout 180
docker compose ps
docker build -f runner/Dockerfile -t dk-mock-python:1 .
~~~

Up만으로 Kafka 준비 완료를 단정하지 말고 healthy 또는 토픽 조회 성공을 확인합니다. 오류 시:

~~~text
docker compose logs --tail 50 kafka
docker compose exec kafka kafka-topics --list --bootstrap-server localhost:9092
~~~

서비스 이름은 kafka, 컨테이너 이름은 dk-mock-kafka입니다. Kafka CLI는 docker compose exec kafka로 시작하고 실행 파일에 bin/과 .sh를 붙이지 않습니다. Python 실행기는 --network container:dk-mock-kafka로 Kafka와 네트워크 공간을 공유하여 localhost:9092를 사용합니다. 일반 별도 컨테이너의 localhost가 Kafka를 가리킨다는 뜻은 아닙니다. Python은 일회성 docker run으로 실행하고 공통 Compose에 서비스를 추가하지 않습니다. 이 연결 방식은 제공 사항이며 암기·평가하지 않습니다.

## 수정 범위

- answers/q01.txt~q07.txt, q12.md: 명령·원인·서술 답안
- tasks/q02/Dockerfile, app.py: Dockerfile 완성과 Flask 바인딩 오류 수정
- tasks/q04/compose.yml: 웹 Compose 완성
- tasks/q08_admin.py~q11_pipeline.py: Python 함수 구현
- evidence/: 문항별 실행 결과와 캡처
- data/errors.txt, empty-errors.txt: Q03에서 생성하는 결과

나머지 제공 파일과 입력 데이터는 수정 금지입니다. Python 시작 파일은 문법상 유효하고 미구현 함수 호출 시 NotImplementedError가 나는 것이 정상입니다. Dockerfile·웹 Compose도 풀이 전에는 목표 기능을 수행하지 않습니다.

## 실행 순서

Q01~04는 독립적입니다. Q05부터 Kafka를 사용합니다. Q08이 Python용 토픽을 준비하고 Q09가 여섯 건을 전송하며 Q10이 이를 읽습니다. Q11은 별도 입력·출력 토픽을 씁니다. 앞 단계가 미완성이면 토픽/데이터가 준비되지 않습니다. 함수 테스트는 각 문제를 독립적으로 확인할 수 있습니다.

Q08~10 실행:

~~~text
docker run --rm --network container:dk-mock-kafka -v "${PWD}:/exam" -w /exam dk-mock-python:1 python support/live.py admin
docker run --rm --network container:dk-mock-kafka -v "${PWD}:/exam" -w /exam dk-mock-python:1 python support/live.py produce
docker run --rm --network container:dk-mock-kafka -v "${PWD}:/exam" -w /exam dk-mock-python:1 python support/live.py consume --group mk-reader-1
~~~

Q10 재독에는 새 그룹 이름 mk-reader-2 등을 사용합니다. 같은 그룹의 earliest가 기존 커밋 위치를 초기화하지는 않습니다. produce를 재실행하면 6건이 추가됩니다. 여섯 행은 key/value의 중복 포함 집합으로 비교하고 전체 파티션 간 출력 순서는 고정하지 않습니다. 컨슈머는 새 입력이 없는 시간이 10초가 되면 종료합니다. 기동 지연으로 못 읽었다면 준비 상태를 확인하고 재시도하세요.

Q11은 아래 프로듀서 입력창에 data/pipeline_messages.txt의 네 줄을 입력합니다. 세 번째 줄은 공백 세 칸입니다. 이것은 명령이 아닌 메시지 본문입니다. 입력 후 Ctrl+C로 종료합니다.

~~~text
docker compose exec kafka kafka-console-producer --bootstrap-server localhost:9092 --topic mk-input
docker run --rm --network container:dk-mock-kafka -v "${PWD}:/exam" -w /exam dk-mock-python:1 python support/live.py pipeline --group mk-pipeline-1
docker compose exec kafka kafka-console-consumer --bootstrap-server localhost:9092 --topic mk-output --partition 0 --from-beginning --max-messages 3 --timeout-ms 10000
~~~

빈 환경에서 한 번 실행한 결과는 COFFEE / TEA / 한글입니다. 출력 토픽에 기존 데이터가 있으면 첫 세 건 조회는 최신 실행 검증이 아닙니다. 초기화 후 재연습하거나 실행 전후 오프셋과 추가 건수를 비교하세요.

## 자동·수동 검증

~~~text
docker run --rm -v "${PWD}:/exam" -w /exam dk-mock-python:1 python tests/test_contracts.py tasks
~~~

26개 테스트는 Q08~11의 정상·빈 입력·한글·오류 전파를 검사합니다. Kafka 대역 객체를 사용하므로 실제 브로커·네트워크·리밸런스 검증을 대신하지 않습니다. 특정 테스트만 선택하려면 명령 끝에 ExamTests.test_admin_empty처럼 이름을 붙입니다. 테스트는 명시된 요구사항과 기대 결과를 담고 있고 정답 구현은 없습니다.

Q01~07·Q12는 문제의 배점 기준과 별도 해설의 점검표로 채점합니다. Q02 응답은 브라우저의 http://localhost:5080/에서, Q04는 http://localhost:8088/에서 확인할 수 있습니다. 실제 실행을 하지 않았다면 evidence에 명령 작성만 했다고 기록하세요.

## 재연습과 정리

일반 종료는 Kafka 데이터 볼륨을 보존합니다.

~~~text
docker compose down
~~~

처음부터 재연습할 때만 아래 초기화를 수행합니다. dk-mock 프로젝트의 Kafka 볼륨과 모든 연습 토픽·오프셋이 삭제됩니다. 다른 프로젝트는 대상이 아닙니다. mk-web이 없을 때 발생하는 정리 오류는 무시할 수 있습니다.

~~~text
docker stop mk-web
docker rm mk-web
docker compose -f tasks/q04/compose.yml down
docker compose down -v
docker compose up -d --wait --wait-timeout 180
~~~

Q08을 다시 실행해 Python용 토픽도 준비하세요. system prune이나 전체 이미지 삭제는 필요하지 않습니다.

## 제출

함수명·파일명을 유지합니다. 다음 명령은 answers, tasks, evidence 및 Q03 결과만 submission.zip에 넣습니다. 정답·Docker 이미지·볼륨·캐시는 포함하지 않습니다.

~~~text
docker run --rm -v "${PWD}:/exam" -w /exam dk-mock-python:1 python support/package.py
~~~

실제 평가의 제출 규칙은 당일 공지를 따르세요.

## 선택: 실제 Kafka 결과 자동 대조

깨끗한 환경에서 Q09와 Q11을 각각 한 번 실행한 뒤 아래 검사를 사용할 수 있습니다. 실제 토픽 파티션 수, 중복을 포함한 여섯 건의 키·값, 같은 키의 파티션 유지, 세 건의 변환 결과를 검사합니다. 데이터가 추가된 상태에서는 의도적으로 실패하므로 재연습 안내를 확인하세요. 이 검사는 제작 환경에서는 실행하지 못했습니다.

~~~text
docker run --rm --network container:dk-mock-kafka -v "${PWD}:/exam" -w /exam dk-mock-python:1 python support/verify_live.py orders
docker run --rm --network container:dk-mock-kafka -v "${PWD}:/exam" -w /exam dk-mock-python:1 python support/verify_live.py pipeline
~~~
